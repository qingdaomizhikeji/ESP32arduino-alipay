var dir_978795e90a3da7818437a72e75b84db8 =
[
    [ "Duck.cpp", "_duck_8cpp.html", null ],
    [ "DuckDetect.cpp", "_duck_detect_8cpp.html", null ],
    [ "DuckLink.cpp", "_duck_link_8cpp.html", null ],
    [ "MamaDuck.cpp", "_mama_duck_8cpp.html", null ],
    [ "PapaDuck.cpp", "_papa_duck_8cpp.html", null ]
];