var class_duck_led =
[
    [ "setColor", "class_duck_led.html#a0a4539a7251dc82a93c23f2953b61501", null ],
    [ "setupLED", "class_duck_led.html#a3c7612e65d560f4c2b548baa50b2a120", null ]
];