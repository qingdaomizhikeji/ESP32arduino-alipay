var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "Ducks", "dir_978795e90a3da7818437a72e75b84db8.html", "dir_978795e90a3da7818437a72e75b84db8" ],
    [ "include", "dir_b0856f6b0d80ccb263b2f415c91f9e17.html", "dir_b0856f6b0d80ccb263b2f415c91f9e17" ]
];