var _duck_esp_8h =
[
    [ "getDuckMacAddress", "_duck_esp_8h.html#abe3768516690b9177254cb1a83b3cf14", null ],
    [ "restartDuck", "_duck_esp_8h.html#a1bccb912823b8261c7ef8559efc3d5ec", null ]
];