var _duck_utils_8h =
[
    [ "convertToHex", "_duck_utils_8h.html#a300c7308d5e925e24760841d70bd59b6", null ],
    [ "createUuid", "_duck_utils_8h.html#a0e3cad4a86a31255d7fe4cedc0160d6b", null ],
    [ "getDuckInterrupt", "_duck_utils_8h.html#aeeb72b7ef813ecd6ebad844c76e1036d", null ],
    [ "getTimer", "_duck_utils_8h.html#afdb0bf8814af2145ed0d183ad5523157", null ],
    [ "setDuckInterrupt", "_duck_utils_8h.html#a88fa5623a4029594912d38341d4bbfae", null ],
    [ "duckTimer", "_duck_utils_8h.html#a6a89c26b27f49a64aa4ad62479da0327", null ],
    [ "enableDuckInterrupt", "_duck_utils_8h.html#ad05a5136ce402f494840e02f0e0816dd", null ]
];