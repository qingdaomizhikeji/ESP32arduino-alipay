var _duck_types_8h =
[
    [ "DuckType", "_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4a", [
      [ "UNKNOWN", "_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aa6ce26a62afab55d7606ad4e92428b30c", null ],
      [ "PAPA", "_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aae3eec4dfdc41211205c40372d228ed25", null ],
      [ "MAMA", "_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aa324f3d8a8abafdef821a168b2c2e3a3e", null ],
      [ "LINK", "_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aaf2fe1bf26da6f8a451f054e30b3ce0f3", null ],
      [ "DETECTOR", "_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aabbc3cf4a9cbee11e6dc95c58594dc677", null ],
      [ "MAX_TYPE", "_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aacde90f0aafc1967e6a602267a564a0cc", null ]
    ] ]
];