var indexSectionsWithContent =
{
  0: "abcdefghilmoprstu~",
  1: "dlp",
  2: "d",
  3: "cdhilmop",
  4: "cdghiloprst~",
  5: "bdefimprst",
  6: "d",
  7: "dlmpu",
  8: "ac",
  9: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

