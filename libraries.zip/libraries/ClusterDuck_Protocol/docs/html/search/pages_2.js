var searchData=
[
  ['issues_605',['Issues',['../md_contributing__i_s_s_u_e_s.html',1,'']]]
];
