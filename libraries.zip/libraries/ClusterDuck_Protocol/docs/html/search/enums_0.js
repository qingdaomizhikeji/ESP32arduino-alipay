var searchData=
[
  ['ducktype_267',['DuckType',['../_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4a',1,'DuckTypes.h']]]
];
