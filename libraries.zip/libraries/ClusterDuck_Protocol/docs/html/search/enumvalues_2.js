var searchData=
[
  ['mama_270',['MAMA',['../_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aa324f3d8a8abafdef821a168b2c2e3a3e',1,'DuckTypes.h']]],
  ['max_5ftype_271',['MAX_TYPE',['../_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aacde90f0aafc1967e6a602267a564a0cc',1,'DuckTypes.h']]]
];
