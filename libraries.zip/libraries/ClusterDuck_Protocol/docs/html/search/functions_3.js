var searchData=
[
  ['handleotaupdate_200',['handleOtaUpdate',['../class_duck.html#ac9407d040d345391b1aecfb18404542f',1,'Duck']]],
  ['handlepacket_201',['handlePacket',['../class_duck_lora.html#a498cb19262425f8dd564da347bbb6b55',1,'DuckLora']]]
];
