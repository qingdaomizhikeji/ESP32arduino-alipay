var searchData=
[
  ['pull_20requests_606',['Pull requests',['../md_contributing__p_u_l_l-_r_e_q_u_e_s_t_s.html',1,'']]]
];
