var searchData=
[
  ['detector_268',['DETECTOR',['../_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aabbc3cf4a9cbee11e6dc95c58594dc677',1,'DuckTypes.h']]]
];
