var searchData=
[
  ['papa_272',['PAPA',['../_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aae3eec4dfdc41211205c40372d228ed25',1,'DuckTypes.h']]]
];
