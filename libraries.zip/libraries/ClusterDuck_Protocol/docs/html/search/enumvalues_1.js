var searchData=
[
  ['link_269',['LINK',['../_duck_types_8h.html#ae840cd9270fc5804ad85c80de1686d4aaf2fe1bf26da6f8a451f054e30b3ce0f3',1,'DuckTypes.h']]]
];
