var class_duck_net =
[
    [ "getPassword", "class_duck_net.html#a42964c0c02292c1ae64e04fcc4e6b041", null ],
    [ "getSsid", "class_duck_net.html#a118d833abc97de5713b5d4b874e13304", null ],
    [ "isWifiConnected", "class_duck_net.html#a393440e488e564a2269bdec8a218f1a2", null ],
    [ "setDeviceId", "class_duck_net.html#a14bd891ce84c320913b0d50b01440e8e", null ],
    [ "setPassword", "class_duck_net.html#ae345c3caeff634d0ddb95203181b2fa5", null ],
    [ "setSsid", "class_duck_net.html#ae63fc1f14a23720b188b0cc086193090", null ],
    [ "setupDns", "class_duck_net.html#adf1b556e746790e133583abb73329cb0", null ],
    [ "setupInternet", "class_duck_net.html#ab3124994bb8d9b13109b513dde7a1f0e", null ],
    [ "setupWebServer", "class_duck_net.html#ab9844f05f1bd951e0661d21c161bf393", null ],
    [ "setupWifiAp", "class_duck_net.html#ab8110f22f23e91cca341296bfa9d147a", null ],
    [ "ssidAvailable", "class_duck_net.html#a31177d7df7993a80c24d9f076420d20d", null ]
];