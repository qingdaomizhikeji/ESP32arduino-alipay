var namespaces_dup =
[
    [ "duckesp", "namespaceduckesp.html", null ],
    [ "duckutils", "namespaceduckutils.html", null ]
];