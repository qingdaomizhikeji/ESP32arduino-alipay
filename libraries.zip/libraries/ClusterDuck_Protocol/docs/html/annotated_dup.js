var annotated_dup =
[
    [ "Duck", "class_duck.html", "class_duck" ],
    [ "DuckLed", "class_duck_led.html", "class_duck_led" ],
    [ "DuckLora", "class_duck_lora.html", "class_duck_lora" ],
    [ "DuckNet", "class_duck_net.html", "class_duck_net" ],
    [ "LoraConfigParams", "struct_lora_config_params.html", "struct_lora_config_params" ],
    [ "Packet", "struct_packet.html", "struct_packet" ]
];