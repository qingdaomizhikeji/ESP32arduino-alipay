## ClusterDuck Protocol - Simple Duck Case
This folder includs two files to 3D print your own Duck Case. This case is designed to be used with the following products.

#### - Heltec Wifi Lora ESP32 https://heltec.org/project/wifi-lora-32/
Note: Check Local Rules and regulations for frequency. Can be bought from different sellers. 

#### - Battery Case https://tinyurl.com/qsep8ru

#### - JST 1.25mm 2pin connector Male https://tinyurl.com/wfjj4bq


![CDP-BOX](/docs/assets/images/CDP_BOX.jpg)

